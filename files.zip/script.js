/* ===== DATA SETS PER PERIOD ===== */
const periodData = {
  today: {
    label:'Today', total:'47', ai:'168', consult:'52',
    chgTotal:'↑ 6% vs yesterday', chgAI:'↑ 3% vs yesterday', chgConsult:'↑ 9% vs yesterday',
    chgTotalUp:true, chgAIUp:true, chgConsultUp:true,
    breakdown:[
      {cat:'New Admissions',   count:12, pct:'25%', vs:'+2',  st:'gr'},
      {cat:'Outpatient Visits',count:24, pct:'51%', vs:'+5',  st:'bl'},
      {cat:'ICU Patients',     count:5,  pct:'11%', vs:'−1',  st:'rd'},
      {cat:'Discharged',       count:6,  pct:'13%', vs:'+1',  st:'am'},
    ],
    barLabels:['8AM','10AM','12PM','2PM','4PM','6PM','8PM'],
    inP:[6,9,12,10,8,5,4], outP:[10,15,18,16,12,8,6]
  },
  week: {
    label:'This Week', total:'348', ai:'1,204', consult:'348',
    chgTotal:'↑ 12% vs last week', chgAI:'↑ 8% vs last week', chgConsult:'↓ 3% vs last week',
    chgTotalUp:true, chgAIUp:true, chgConsultUp:false,
    breakdown:[
      {cat:'New Admissions',   count:89,  pct:'26%', vs:'+14', st:'gr'},
      {cat:'Outpatient Visits',count:178, pct:'51%', vs:'+21', st:'bl'},
      {cat:'ICU Patients',     count:34,  pct:'10%', vs:'−3',  st:'rd'},
      {cat:'Discharged',       count:47,  pct:'14%', vs:'+8',  st:'am'},
    ],
    barLabels:['Mon','Tue','Wed','Thu','Fri','Sat','Sun'],
    inP:[65,80,72,90,85,55,48], outP:[110,130,120,145,138,90,75]
  },
  month: {
    label:'This Month', total:'1,420', ai:'4,890', consult:'1,390',
    chgTotal:'↑ 9% vs last month', chgAI:'↑ 11% vs last month', chgConsult:'↑ 5% vs last month',
    chgTotalUp:true, chgAIUp:true, chgConsultUp:true,
    breakdown:[
      {cat:'New Admissions',   count:362, pct:'25%', vs:'+41', st:'gr'},
      {cat:'Outpatient Visits',count:724, pct:'51%', vs:'+88', st:'bl'},
      {cat:'ICU Patients',     count:142, pct:'10%', vs:'−12', st:'rd'},
      {cat:'Discharged',       count:192, pct:'14%', vs:'+33', st:'am'},
    ],
    barLabels:['Wk1','Wk2','Wk3','Wk4'],
    inP:[280,320,350,310], outP:[480,520,570,500]
  },
  year: {
    label:'This Year', total:'16,847', ai:'58,320', consult:'14,210',
    chgTotal:'↑ 18% vs last year', chgAI:'↑ 24% vs last year', chgConsult:'↑ 15% vs last year',
    chgTotalUp:true, chgAIUp:true, chgConsultUp:true,
    breakdown:[
      {cat:'New Admissions',   count:4292,  pct:'25%', vs:'+620', st:'gr'},
      {cat:'Outpatient Visits',count:8594,  pct:'51%', vs:'+1240',st:'bl'},
      {cat:'ICU Patients',     count:1685,  pct:'10%', vs:'−88',  st:'rd'},
      {cat:'Discharged',       count:2276,  pct:'14%', vs:'+410', st:'am'},
    ],
    barLabels:['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],
    inP:[1100,980,1200,1350,1420,1500,1380,1450,1300,1250,1180,1100],
    outP:[1800,1650,2000,2200,2300,2400,2250,2350,2100,2050,1950,1800]
  }
};

let currentPeriod = 'week';

/* ===== TIME FILTER ===== */
function toggleTF(){
  const btn=document.getElementById('tf-btn');
  const dd=document.getElementById('tf-dd');
  btn.classList.toggle('open');
  dd.classList.toggle('open');
}
document.addEventListener('click',function(e){
  if(!document.getElementById('tf').contains(e.target)){
    document.getElementById('tf-btn').classList.remove('open');
    document.getElementById('tf-dd').classList.remove('open');
  }
});

function setPeriod(p){
  currentPeriod=p;
  const d=periodData[p];
  document.getElementById('tf-label').textContent=d.label;
  document.getElementById('tf-btn').classList.remove('open');
  document.getElementById('tf-dd').classList.remove('open');
  document.querySelectorAll('.time-opt').forEach(o=>{
    o.classList.remove('sel');
    o.innerHTML=o.innerHTML.replace('<span class="tick">✓</span>','');
  });
  const opts=document.querySelectorAll('.time-opt');
  const idx={today:0,week:1,month:2,year:3}[p];
  opts[idx].classList.add('sel');
  opts[idx].innerHTML+='<span class="tick">✓</span>';
  document.getElementById('stat-total').textContent=d.total;
  document.getElementById('stat-ai').textContent=d.ai;
  document.getElementById('stat-consult').textContent=d.consult;
  document.getElementById('lbl-period').textContent=d.label.toLowerCase();
  document.getElementById('lbl-period2').textContent=d.label.toLowerCase();
  const chgT=document.getElementById('stat-total-chg');
  chgT.textContent=d.chgTotal; chgT.className='s-chg '+(d.chgTotalUp?'up':'dn');
  const chgA=document.getElementById('stat-ai-chg');
  chgA.textContent=d.chgAI; chgA.className='s-chg '+(d.chgAIUp?'up':'dn');
  const chgC=document.getElementById('stat-consult-chg');
  chgC.textContent=d.chgConsult; chgC.className='s-chg '+(d.chgConsultUp?'up':'dn');
  document.getElementById('breakdown-title').textContent='Patient Breakdown — '+d.label;
  document.getElementById('chart-title').textContent='Admissions — '+d.label;
  const tbody=document.getElementById('breakdown-body');
  tbody.innerHTML='';
  d.breakdown.forEach(r=>{
    const up=r.vs.startsWith('+');
    tbody.innerHTML+=`<tr>
      <td>${r.cat}</td>
      <td><strong>${r.count.toLocaleString()}</strong></td>
      <td>${r.pct}</td>
      <td style="color:${up?'var(--green)':'var(--red)'}">${r.vs}</td>
      <td><span class="badge ${r.st}">${r.st==='gr'?'Good':r.st==='bl'?'Normal':r.st==='rd'?'Critical':'Watch'}</span></td>
    </tr>`;
  });
  buildChart(d.barLabels, d.inP, d.outP);
  document.getElementById('sb-pat-count').textContent=d.total;
}

function buildChart(labels, inP, outP){
  const c=document.getElementById('adm-chart');
  c.innerHTML='';
  const mx=Math.max(...outP);
  labels.forEach((lbl,i)=>{
    const w=document.createElement('div');w.className='bar-wrap';
    const inner=document.createElement('div');inner.className='b-inner';
    const b1=document.createElement('div');b1.className='bar b-bl';b1.style.height='0';
    const b2=document.createElement('div');b2.className='bar b-gr';b2.style.height='0';
    const l=document.createElement('div');l.className='bar-lbl';l.textContent=lbl;
    inner.appendChild(b1);inner.appendChild(b2);w.appendChild(inner);w.appendChild(l);c.appendChild(w);
    setTimeout(()=>{b1.style.height=(inP[i]/mx*100)+'%';b2.style.height=(outP[i]/mx*100)+'%'},80+i*40);
  });
}

/* ===== AUTH ===== */
function switchTab(t){
  document.getElementById('tab-login').classList.toggle('active',t==='login');
  document.getElementById('tab-signup').classList.toggle('active',t==='signup');
  document.getElementById('apage-login').classList.toggle('show',t==='login');
  document.getElementById('apage-signup').classList.toggle('show',t==='signup');
}
function toggleEye(id,eid){
  const i=document.getElementById(id),e=document.getElementById(eid);
  i.type=i.type==='password'?'text':'password';
  e.textContent=i.type==='password'?'👁':'🙈';
}
function pickRole(el){
  document.querySelectorAll('.role-opt').forEach(r=>r.classList.remove('picked'));
  el.classList.add('picked');
}
function checkStr(v){
  const segs=['ss1','ss2','ss3','ss4'].map(id=>document.getElementById(id));
  const lbl=document.getElementById('str-lbl');
  let s=0;
  if(v.length>=8)s++;if(/[A-Z]/.test(v))s++;if(/[0-9]/.test(v))s++;if(/[^A-Za-z0-9]/.test(v))s++;
  const cols=['#ef4444','#f59e0b','#3b82f6','#10b981'];
  const labs=['Weak','Fair','Good','Strong'];
  segs.forEach((sg,i)=>{sg.style.background=i<s?cols[s-1]:'var(--bg4)'});
  lbl.textContent=v.length?(labs[s-1]||''):'';
  lbl.style.color=v.length?(cols[s-1]||'var(--text3)'):'var(--text3)';
}
function doLogin(){
  document.getElementById('auth-screen').style.display='none';
  document.getElementById('app-screen').classList.add('visible');
  setPeriod('week');
}

/* ===== APP NAV ===== */
const pageTitles={overview:'Overview',patients:'Patient Records',monitoring:'Remote Patient Monitoring',imaging:'Medical Imaging',ai:'AI Engine',genomics:'Genomics',analytics:'Analytics',telemedicine:'Telemedicine',ehr:'EHR Records',settings:'Settings'};
function showPage(id,el){
  document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
  document.getElementById('page-'+id).classList.add('active');
  document.querySelectorAll('.nav-item').forEach(n=>n.classList.remove('active'));
  if(el)el.classList.add('active');
  document.getElementById('page-title').textContent=pageTitles[id]||'Dashboard';
}
function toggleSB(){
  document.getElementById('sidebar').classList.toggle('collapsed');
}

/* ===== LOGOUT ===== */
function showLogout(){
  document.getElementById('app-screen').classList.remove('visible');
  document.getElementById('logout-screen').classList.add('show');
}
function cancelLogout(){
  document.getElementById('app-screen').classList.add('visible');
  document.getElementById('logout-screen').classList.remove('show');
}
function confirmLogout(){
  document.getElementById('logout-screen').classList.remove('show');
  document.getElementById('auth-screen').style.display='flex';
}

/* ===== UPLOAD SCAN ===== */
let uploadFile = null;

const aiFindings = {
  'X-Ray': [
    {col:'#10b981', text:'No pneumothorax or pleural effusion detected'},
    {col:'#f59e0b', text:'Mild cardiomegaly noted — cardiothoracic ratio 0.54'},
    {col:'#10b981', text:'Lung fields clear bilaterally'},
    {col:'#3b82f6', text:'Bony structures intact, no acute fractures'}
  ],
  'CT Scan': [
    {col:'#ef4444', text:'Small hypodense lesion in right hepatic lobe (8mm) — follow-up recommended'},
    {col:'#10b981', text:'No evidence of intracranial hemorrhage'},
    {col:'#f59e0b', text:'Mild emphysematous changes in upper lobes'},
    {col:'#10b981', text:'Mediastinum and hila normal in appearance'}
  ],
  'MRI': [
    {col:'#10b981', text:'Brain parenchyma shows normal signal intensity'},
    {col:'#f59e0b', text:'T2 hyperintensity in periventricular white matter — age-related changes'},
    {col:'#10b981', text:'No acute infarct or diffusion restriction'},
    {col:'#3b82f6', text:'Ventricles and sulci normal for age'}
  ],
  'default': [
    {col:'#10b981', text:'Scan processed successfully by AI engine'},
    {col:'#3b82f6', text:'No critical anomalies flagged in primary analysis'},
    {col:'#f59e0b', text:'One region of interest identified for radiologist review'},
    {col:'#10b981', text:'Report queued for attending physician'}
  ]
};

function openUploadModal(){
  resetUploadModal();
  document.getElementById('upload-modal').classList.add('open');
}
function closeUploadModal(){
  document.getElementById('upload-modal').classList.remove('open');
}
function resetUploadModal(){
  uploadFile=null;
  document.getElementById('drop-zone').style.display='block';
  document.getElementById('scan-preview').style.display='none';
  document.getElementById('scan-fields').style.display='none';
  document.getElementById('upload-progress').style.display='none';
  document.getElementById('ai-result').style.display='none';
  document.getElementById('upload-btn').disabled=true;
  document.getElementById('upload-btn').textContent='Analyse Scan →';
  document.getElementById('scan-file').value='';
  ['step-1','step-2','step-3','step-4'].forEach(id=>{
    const el=document.getElementById(id);
    el.classList.remove('done','active');
  });
  document.getElementById('up-bar').style.width='0%';
}
function removeFile(){
  uploadFile=null;
  document.getElementById('scan-preview').style.display='none';
  document.getElementById('scan-fields').style.display='none';
  document.getElementById('drop-zone').style.display='block';
  document.getElementById('upload-btn').disabled=true;
  document.getElementById('scan-file').value='';
}
function handleFileSelect(input){
  if(!input.files||!input.files[0])return;
  uploadFile=input.files[0];
  const ext=uploadFile.name.split('.').pop().toUpperCase();
  const icons={DCM:'🩻',JPG:'🖼',JPEG:'🖼',PNG:'🖼',PDF:'📄',TIFF:'🔬'};
  const sz=(uploadFile.size/1024)<1024?(uploadFile.size/1024).toFixed(1)+' KB':((uploadFile.size/1024)/1024).toFixed(2)+' MB';
  document.getElementById('preview-thumb').textContent=icons[ext]||'📁';
  document.getElementById('preview-name').textContent=uploadFile.name;
  document.getElementById('preview-meta').textContent=sz+' · Ready for AI analysis';
  document.getElementById('drop-zone').style.display='none';
  document.getElementById('scan-preview').style.display='block';
  document.getElementById('scan-fields').style.display='grid';
  document.getElementById('upload-btn').disabled=false;
  document.getElementById('ai-result').style.display='none';
  document.getElementById('upload-progress').style.display='none';
}
function startUpload(){
  if(!uploadFile)return;
  document.getElementById('upload-progress').style.display='block';
  document.getElementById('upload-btn').disabled=true;
  document.getElementById('upload-btn').textContent='Analysing…';
  document.getElementById('ai-result').style.display='none';
  const steps=['step-1','step-2','step-3','step-4'];
  const pcts=[20,50,80,100];
  const labels=['Encrypting…','Uploading…','Running AI…','Building report…'];
  let i=0;
  function runStep(){
    if(i>0)document.getElementById(steps[i-1]).classList.remove('active');
    if(i>0)document.getElementById(steps[i-1]).classList.add('done');
    if(i<steps.length){
      document.getElementById(steps[i]).classList.add('active');
      document.getElementById('up-label').textContent=labels[i];
      document.getElementById('up-pct').textContent=pcts[i]+'%';
      document.getElementById('up-bar').style.width=pcts[i]+'%';
      i++;
      setTimeout(runStep,900+Math.random()*400);
    } else {
      showResult();
    }
  }
  runStep();
}
function showResult(){
  document.getElementById('upload-btn').textContent='Done ✓';
  const scanType=document.getElementById('scan-type').value||'default';
  const findings=aiFindings[scanType]||aiFindings['default'];
  const conf=(95+Math.random()*4).toFixed(1)+'%';
  document.getElementById('conf-val').textContent=conf;
  const container=document.getElementById('result-findings');
  container.innerHTML='';
  findings.forEach(f=>{
    container.innerHTML+=`<div class="finding"><div class="finding-dot" style="background:${f.col}"></div><div class="finding-text">${f.text}</div></div>`;
  });
  document.getElementById('ai-result').style.display='block';
  const queue=document.querySelector('#page-imaging .card:last-child .card-t');
  const patient=document.getElementById('scan-patient').value||'Unknown patient';
  const type=document.getElementById('scan-type').value||'Scan';
  if(queue){
    const newScan=document.createElement('div');
    newScan.style.cssText='background:var(--bg3);border-radius:10px;padding:14px;margin-top:9px;border-left:3px solid var(--accent)';
    newScan.innerHTML=`<div style="display:flex;justify-content:space-between;margin-bottom:3px"><span style="font-size:13px;font-weight:500">${patient.split('—')[0].trim()} — ${type}</span><span class="badge gr">AI Done</span></div><div style="font-size:11px;color:var(--text2)">Confidence ${conf} · Just now</div>`;
    queue.parentElement.appendChild(newScan);
  }
}

/* Drag & drop */
const dz=document.getElementById('drop-zone');
if(dz){
  dz.addEventListener('dragover',e=>{e.preventDefault();dz.classList.add('drag')});
  dz.addEventListener('dragleave',()=>dz.classList.remove('drag'));
  dz.addEventListener('drop',e=>{
    e.preventDefault();dz.classList.remove('drag');
    if(e.dataTransfer.files&&e.dataTransfer.files[0]){
      uploadFile=e.dataTransfer.files[0];
      handleFileSelect({files:e.dataTransfer.files});
    }
  });
}
/* Close modal on overlay click */
document.getElementById('upload-modal').addEventListener('click',function(e){
  if(e.target===this)closeUploadModal();
});
