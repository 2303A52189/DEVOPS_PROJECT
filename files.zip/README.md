# CloudHealth AI 🏥

Smart Healthcare System powered by Artificial Intelligence

## Project Structure

```
cloudhealth-ai/
├── index.html      ← Main HTML (structure & pages)
├── styles.css      ← All styles & CSS variables
├── script.js       ← All JavaScript logic
└── README.md       ← This file
```

## Features

- 🔐 Login / Sign Up with role selection
- 📊 Dashboard Overview with live time filters
- 👥 Patient Records management
- 💓 Remote Patient Monitoring (RPM)
- 🔬 Medical Imaging with AI Upload Scan
- 🤖 AI Engine with 6 active models
- 🧬 Genomics & Personalised Medicine
- 📈 Analytics & global health data
- 📡 Telemedicine consultations
- 📋 EHR Records
- ⚙️ Settings with toggles
- ⇠ Sign Out button (topbar + sidebar)

## How to Run

Just open `index.html` in any browser — no server needed.

## Deploy to GitHub Pages

```bash
git init
git add .
git commit -m "CloudHealth AI - initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/cloudhealth-ai.git
git push -u origin main
```

Then go to: Settings → Pages → Source: main → Save

Your site will be live at:
`https://YOUR_USERNAME.github.io/cloudhealth-ai/`
